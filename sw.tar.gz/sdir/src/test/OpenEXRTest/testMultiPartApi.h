//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTMULTIPARTAPI_H_
#define TESTMULTIPARTAPI_H_

#include <string>

void testMultiPartApi (const std::string& tempDir);

#endif /* TESTMULTIPARTAPI_H_ */
